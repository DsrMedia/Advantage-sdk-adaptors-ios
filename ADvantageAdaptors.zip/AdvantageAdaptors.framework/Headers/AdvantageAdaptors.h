//
//  AdvantageAdaptors.h
//  AdvantageAdaptors
//
//  Created by Renato Neves Ribeiro on 13.03.20.
//  Copyright © 2020 Digital Sunray. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AdvantageAdaptors.
FOUNDATION_EXPORT double AdvantageAdaptorsVersionNumber;

//! Project version string for AdvantageAdaptors.
FOUNDATION_EXPORT const unsigned char AdvantageAdaptorsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdvantageAdaptors/PublicHeader.h>

#import <AdvantageAdaptors/ADvantageTeadsAdaptor.h>
