#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ADvantageTeadsAdaptor : NSObject

@property (nonatomic, assign) BOOL debugEnabled;

@end
